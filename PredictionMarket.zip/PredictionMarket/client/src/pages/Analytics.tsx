import Header from "@/components/Header";
import StatsCard from "@/components/StatsCard";
import AnalyticsDashboard from "@/components/AnalyticsDashboard";
import { TrendingUp, Users, Target, Sparkles } from "lucide-react";

export default function Analytics() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-12">
        <div className="space-y-8">
          <div>
            <h1 className="text-4xl font-bold mb-2">Platform Analytics</h1>
            <p className="text-muted-foreground">
              Real-time insights into market performance and AI accuracy
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatsCard
              title="Total Markets"
              value="156"
              subtitle="24 active now"
              icon={Target}
              trend="+8 this week"
              trendUp={true}
            />
            <StatsCard
              title="Active Users"
              value="2,847"
              subtitle="342 online"
              icon={Users}
              trend="+15% this month"
              trendUp={true}
            />
            <StatsCard
              title="Total Volume"
              value="284K QIE"
              subtitle="$1.42M USD"
              icon={TrendingUp}
              trend="+22% this week"
              trendUp={true}
            />
            <StatsCard
              title="AI Accuracy"
              value="87.3%"
              subtitle="Based on resolved markets"
              icon={Sparkles}
              trend="+2.1% improvement"
              trendUp={true}
            />
          </div>

          <AnalyticsDashboard />
        </div>
      </div>
    </div>
  );
}
