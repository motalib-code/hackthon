import { useState } from "react";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import MarketCard from "@/components/MarketCard";
import ActivityFeed from "@/components/ActivityFeed";
import BettingModal from "@/components/BettingModal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, TrendingUp } from "lucide-react";

// todo: remove mock functionality
const mockMarkets = [
  {
    id: "1",
    question: "Will Bitcoin reach $100,000 by end of 2025?",
    category: "Crypto",
    outcomes: [
      { label: "Yes", odds: 68 },
      { label: "No", odds: 32 }
    ],
    aiProbability: 68,
    aiInsight: "Technical analysis shows strong bullish momentum with institutional adoption increasing. Historical patterns suggest a 68% probability.",
    totalPool: 15420,
    participants: 342,
    endDate: "Dec 31, 2025"
  },
  {
    id: "2",
    question: "Will Ethereum ETF be approved in 2025?",
    category: "Crypto",
    outcomes: [
      { label: "Yes", odds: 72 },
      { label: "No", odds: 28 }
    ],
    aiProbability: 72,
    aiInsight: "Regulatory trends and recent SEC statements indicate high approval likelihood. Market sentiment strongly positive.",
    totalPool: 22100,
    participants: 478,
    endDate: "Dec 31, 2025"
  },
  {
    id: "3",
    question: "Will AI surpass human intelligence by 2030?",
    category: "Technology",
    outcomes: [
      { label: "Yes", odds: 35 },
      { label: "No", odds: 65 }
    ],
    aiProbability: 35,
    aiInsight: "Current AI development pace is exponential but true AGI requires breakthroughs. Experts remain cautiously optimistic.",
    totalPool: 8950,
    participants: 215,
    endDate: "Dec 31, 2030"
  },
  {
    id: "4",
    question: "Will Liverpool win the Premier League 2024-25?",
    category: "Sports",
    outcomes: [
      { label: "Yes", odds: 45 },
      { label: "No", odds: 55 }
    ],
    aiProbability: 45,
    aiInsight: "Strong squad depth and tactical improvements under new management. Current form shows championship potential.",
    totalPool: 12300,
    participants: 289,
    endDate: "May 25, 2025"
  },
  {
    id: "5",
    question: "Will Tesla stock exceed $500 by Q2 2025?",
    category: "Finance",
    outcomes: [
      { label: "Yes", odds: 58 },
      { label: "No", odds: 42 }
    ],
    aiProbability: 58,
    aiInsight: "Production targets being met, FSD rollout accelerating. Market cap growth trajectory supports bullish prediction.",
    totalPool: 18700,
    participants: 412,
    endDate: "Jun 30, 2025"
  },
  {
    id: "6",
    question: "Will a major AI company go public in 2025?",
    category: "Technology",
    outcomes: [
      { label: "Yes", odds: 82 },
      { label: "No", odds: 18 }
    ],
    aiProbability: 82,
    aiInsight: "Multiple AI unicorns in late-stage funding with strong IPO indicators. Market conditions favorable for tech listings.",
    totalPool: 9800,
    participants: 198,
    endDate: "Dec 31, 2025"
  },
];

export default function Home() {
  const [selectedMarket, setSelectedMarket] = useState<typeof mockMarkets[0] | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const filteredMarkets = mockMarkets.filter((market) => {
    const matchesSearch = market.question.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "all" || market.category.toLowerCase() === selectedCategory.toLowerCase();
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <HeroSection />
      
      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <h2 className="text-3xl font-bold flex items-center gap-2">
                <TrendingUp className="h-8 w-8 text-primary" />
                Active Markets
              </h2>
            </div>

            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search markets..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  data-testid="input-search-markets"
                />
              </div>

              <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
                <TabsList className="w-full justify-start overflow-x-auto">
                  <TabsTrigger value="all" data-testid="tab-all">All</TabsTrigger>
                  <TabsTrigger value="crypto" data-testid="tab-crypto">Crypto</TabsTrigger>
                  <TabsTrigger value="sports" data-testid="tab-sports">Sports</TabsTrigger>
                  <TabsTrigger value="technology" data-testid="tab-technology">Technology</TabsTrigger>
                  <TabsTrigger value="finance" data-testid="tab-finance">Finance</TabsTrigger>
                </TabsList>

                <TabsContent value={selectedCategory} className="space-y-4 mt-6">
                  {filteredMarkets.length === 0 ? (
                    <div className="text-center py-12">
                      <p className="text-muted-foreground">No markets found matching your criteria</p>
                    </div>
                  ) : (
                    filteredMarkets.map((market) => (
                      <div
                        key={market.id}
                        onClick={() => setSelectedMarket(market)}
                      >
                        <MarketCard {...market} />
                      </div>
                    ))
                  )}
                </TabsContent>
              </Tabs>
            </div>
          </div>

          <div className="lg:col-span-1">
            <ActivityFeed />
          </div>
        </div>
      </div>

      {selectedMarket && (
        <BettingModal
          isOpen={!!selectedMarket}
          onClose={() => setSelectedMarket(null)}
          marketQuestion={selectedMarket.question}
          outcomes={selectedMarket.outcomes}
        />
      )}
    </div>
  );
}
