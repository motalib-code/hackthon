import Header from "@/components/Header";
import StatsCard from "@/components/StatsCard";
import PortfolioTable from "@/components/PortfolioTable";
import { Wallet, TrendingUp, Award, Target } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

// todo: remove mock functionality
const portfolioData = [
  { date: "Jan", value: 1200 },
  { date: "Feb", value: 1450 },
  { date: "Mar", value: 1680 },
  { date: "Apr", value: 1820 },
  { date: "May", value: 2100 },
  { date: "Jun", value: 2450 },
];

export default function Portfolio() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-12">
        <div className="space-y-8">
          <div>
            <h1 className="text-4xl font-bold mb-2">My Portfolio</h1>
            <p className="text-muted-foreground">Track your bets, earnings, and performance</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatsCard
              title="Total Value"
              value="2,450 QIE"
              subtitle="$12,250 USD"
              icon={Wallet}
              trend="+12.5% this week"
              trendUp={true}
            />
            <StatsCard
              title="Active Bets"
              value="3"
              subtitle="900 QIE staked"
              icon={Target}
            />
            <StatsCard
              title="Win Rate"
              value="68%"
              subtitle="15 wins / 22 total"
              icon={Award}
              trend="+5% vs last month"
              trendUp={true}
            />
            <StatsCard
              title="Total Earnings"
              value="1,250 QIE"
              subtitle="$6,250 USD"
              icon={TrendingUp}
              trend="+24% this month"
              trendUp={true}
            />
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Portfolio Value Over Time</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={portfolioData}>
                  <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="value"
                    stroke="hsl(var(--primary))"
                    strokeWidth={3}
                    dot={{ fill: "hsl(var(--primary))", strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <PortfolioTable />
        </div>
      </div>
    </div>
  );
}
