import Header from "@/components/Header";
import CreateMarketForm from "@/components/CreateMarketForm";
import { Sparkles } from "lucide-react";

export default function CreateMarket() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto space-y-8">
          <div>
            <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
              <Sparkles className="h-10 w-10 text-primary" />
              Create Market
            </h1>
            <p className="text-muted-foreground">
              Create a new prediction market and let our AI analyze it for you
            </p>
          </div>

          <CreateMarketForm />
        </div>
      </div>
    </div>
  );
}
