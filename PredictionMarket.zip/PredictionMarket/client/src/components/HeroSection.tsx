import { Button } from "@/components/ui/button";
import { ArrowRight, TrendingUp, Brain, Shield } from "lucide-react";
import heroImage from "@assets/generated_images/AI_blockchain_fusion_hero_73527b21.png";

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-background via-background to-primary/5">
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      
      <div className="container mx-auto px-4 py-20 lg:py-32 relative">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20">
              <div className="h-2 w-2 rounded-full bg-primary animate-pulse"></div>
              <span className="text-sm font-medium text-primary">Powered by QIE Blockchain</span>
            </div>

            <h1 className="text-5xl lg:text-6xl font-bold leading-tight" data-testid="text-hero-title">
              AI-Powered Prediction Markets on{" "}
              <span className="bg-gradient-to-r from-primary via-chart-2 to-chart-3 bg-clip-text text-transparent">
                QIE Blockchain
              </span>
            </h1>

            <p className="text-xl text-muted-foreground leading-relaxed" data-testid="text-hero-subtitle">
              Harness cutting-edge AI analytics and blockchain transparency to create, trade, and profit from prediction markets on any real-world event.
            </p>

            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="rounded-full group" data-testid="button-explore-markets">
                Explore Markets
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button size="lg" variant="outline" className="rounded-full" data-testid="button-create-market">
                Create Market
              </Button>
            </div>

            <div className="grid grid-cols-3 gap-6 pt-8 border-t">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-primary">
                  <Brain className="h-4 w-4" />
                  <span className="text-xs font-medium uppercase tracking-wide">AI-Driven</span>
                </div>
                <p className="text-sm text-muted-foreground">GPT-4 Analytics</p>
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-chart-3">
                  <TrendingUp className="h-4 w-4" />
                  <span className="text-xs font-medium uppercase tracking-wide">Fast</span>
                </div>
                <p className="text-sm text-muted-foreground">3s Finality</p>
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-chart-2">
                  <Shield className="h-4 w-4" />
                  <span className="text-xs font-medium uppercase tracking-wide">Secure</span>
                </div>
                <p className="text-sm text-muted-foreground">Trustless</p>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 via-chart-2/20 to-chart-3/20 blur-3xl"></div>
            <img
              src={heroImage}
              alt="AI and Blockchain Fusion"
              className="relative rounded-2xl shadow-2xl w-full"
              data-testid="img-hero"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
