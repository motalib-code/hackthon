import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, X, Sparkles } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function CreateMarketForm() {
  const [outcomes, setOutcomes] = useState(["Yes", "No"]);
  const [question, setQuestion] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [endDate, setEndDate] = useState("");
  const [minStake, setMinStake] = useState("");

  const addOutcome = () => {
    if (outcomes.length < 5) {
      setOutcomes([...outcomes, ""]);
    }
  };

  const removeOutcome = (index: number) => {
    if (outcomes.length > 2) {
      setOutcomes(outcomes.filter((_, i) => i !== index));
    }
  };

  const updateOutcome = (index: number, value: string) => {
    const newOutcomes = [...outcomes];
    newOutcomes[index] = value;
    setOutcomes(newOutcomes);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Market created:", { question, category, description, outcomes, endDate, minStake });
  };

  return (
    <Card className="max-w-3xl">
      <CardHeader>
        <CardTitle className="text-2xl">Create Prediction Market</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="question">Market Question *</Label>
            <Input
              id="question"
              placeholder="e.g., Will Bitcoin reach $100,000 by end of 2025?"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              data-testid="input-question"
              required
            />
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">Category *</Label>
              <Select value={category} onValueChange={setCategory} required>
                <SelectTrigger id="category" data-testid="select-category">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="crypto">Crypto</SelectItem>
                  <SelectItem value="sports">Sports</SelectItem>
                  <SelectItem value="politics">Politics</SelectItem>
                  <SelectItem value="entertainment">Entertainment</SelectItem>
                  <SelectItem value="technology">Technology</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="endDate">End Date *</Label>
              <Input
                id="endDate"
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                data-testid="input-end-date"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Provide context and details about this prediction market..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              data-testid="textarea-description"
            />
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label>Outcomes *</Label>
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={addOutcome}
                disabled={outcomes.length >= 5}
                data-testid="button-add-outcome"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Outcome
              </Button>
            </div>

            <div className="space-y-3">
              {outcomes.map((outcome, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Input
                    placeholder={`Outcome ${index + 1}`}
                    value={outcome}
                    onChange={(e) => updateOutcome(index, e.target.value)}
                    data-testid={`input-outcome-${index}`}
                    required
                  />
                  {outcomes.length > 2 && (
                    <Button
                      type="button"
                      size="icon"
                      variant="ghost"
                      onClick={() => removeOutcome(index)}
                      data-testid={`button-remove-outcome-${index}`}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="minStake">Minimum Stake (QIE) *</Label>
            <Input
              id="minStake"
              type="number"
              placeholder="10"
              value={minStake}
              onChange={(e) => setMinStake(e.target.value)}
              data-testid="input-min-stake"
              required
            />
          </div>

          <div className="rounded-lg border border-primary/20 bg-primary/5 p-4">
            <div className="flex items-start gap-3">
              <div className="rounded-full bg-primary/10 p-2">
                <Sparkles className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-sm mb-1">AI Analysis Available</h4>
                <p className="text-sm text-muted-foreground">
                  Our AI will automatically analyze your market and provide probability predictions based on historical data and current trends.
                </p>
              </div>
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" className="flex-1" data-testid="button-cancel">
              Cancel
            </Button>
            <Button type="submit" className="flex-1 rounded-full" data-testid="button-create">
              Create Market
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
