import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Eye } from "lucide-react";

interface Position {
  id: string;
  market: string;
  outcome: string;
  stake: number;
  currentValue: number;
  potentialReturn: number;
  status: "winning" | "losing" | "pending";
}

// todo: remove mock functionality
const mockPositions: Position[] = [
  {
    id: "1",
    market: "Bitcoin $100k by 2025?",
    outcome: "Yes",
    stake: 250,
    currentValue: 285,
    potentialReturn: 425,
    status: "winning"
  },
  {
    id: "2",
    market: "Ethereum ETF approval in 2025?",
    outcome: "Yes",
    stake: 500,
    currentValue: 465,
    potentialReturn: 750,
    status: "losing"
  },
  {
    id: "3",
    market: "AI surpass human intelligence by 2030?",
    outcome: "No",
    stake: 150,
    currentValue: 155,
    potentialReturn: 320,
    status: "winning"
  },
];

export default function PortfolioTable() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Active Positions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {mockPositions.map((position) => {
            const changePercent = ((position.currentValue - position.stake) / position.stake) * 100;
            
            return (
              <div
                key={position.id}
                className="flex items-center justify-between p-4 rounded-lg border hover-elevate transition-all"
                data-testid={`row-position-${position.id}`}
              >
                <div className="flex-1 min-w-0 space-y-2">
                  <div className="flex items-center gap-3 flex-wrap">
                    <h4 className="font-semibold" data-testid={`text-market-${position.id}`}>
                      {position.market}
                    </h4>
                    <Badge variant={position.outcome === "Yes" ? "default" : "secondary"} className="text-xs">
                      {position.outcome}
                    </Badge>
                  </div>

                  <div className="flex items-center gap-6 text-sm">
                    <div>
                      <span className="text-muted-foreground">Stake: </span>
                      <span className="font-mono font-semibold" data-testid={`text-stake-${position.id}`}>
                        {position.stake} QIE
                      </span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Current: </span>
                      <span className="font-mono font-semibold" data-testid={`text-current-${position.id}`}>
                        {position.currentValue} QIE
                      </span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Potential: </span>
                      <span className="font-mono font-semibold text-primary" data-testid={`text-potential-${position.id}`}>
                        {position.potentialReturn} QIE
                      </span>
                    </div>
                    <div className={`font-semibold ${changePercent >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {changePercent >= 0 ? '+' : ''}{changePercent.toFixed(1)}%
                    </div>
                  </div>
                </div>

                <Button size="sm" variant="ghost" data-testid={`button-view-${position.id}`}>
                  <Eye className="h-4 w-4" />
                </Button>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
