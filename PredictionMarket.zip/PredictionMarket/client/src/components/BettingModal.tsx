import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { Card } from "@/components/ui/card";
import { TrendingUp, Wallet } from "lucide-react";

interface BettingModalProps {
  isOpen: boolean;
  onClose: () => void;
  marketQuestion: string;
  outcomes: { label: string; odds: number }[];
}

export default function BettingModal({
  isOpen,
  onClose,
  marketQuestion,
  outcomes,
}: BettingModalProps) {
  const [selectedOutcome, setSelectedOutcome] = useState(outcomes[0]?.label || "");
  const [betAmount, setBetAmount] = useState("");
  
  const amount = parseFloat(betAmount) || 0;
  const selectedOdds = outcomes.find(o => o.label === selectedOutcome)?.odds || 0;
  const potentialReturn = amount * (selectedOdds / 100);

  const handleConfirm = () => {
    console.log("Bet confirmed:", { selectedOutcome, betAmount, potentialReturn });
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md" data-testid="modal-betting">
        <DialogHeader>
          <DialogTitle className="text-xl" data-testid="text-modal-title">Place Your Bet</DialogTitle>
          <DialogDescription className="text-sm" data-testid="text-modal-question">
            {marketQuestion}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="space-y-3">
            <Label className="text-sm font-medium">Select Outcome</Label>
            <RadioGroup value={selectedOutcome} onValueChange={setSelectedOutcome}>
              {outcomes.map((outcome, idx) => (
                <Card key={idx} className="p-4 hover-elevate cursor-pointer">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <RadioGroupItem value={outcome.label} id={`outcome-${idx}`} data-testid={`radio-outcome-${idx}`} />
                      <Label htmlFor={`outcome-${idx}`} className="cursor-pointer font-medium">
                        {outcome.label}
                      </Label>
                    </div>
                    <span className="font-mono font-semibold text-primary" data-testid={`text-modal-odds-${idx}`}>
                      {outcome.odds}%
                    </span>
                  </div>
                </Card>
              ))}
            </RadioGroup>
          </div>

          <div className="space-y-3">
            <Label htmlFor="amount" className="text-sm font-medium">Bet Amount (QIE)</Label>
            <div className="relative">
              <Input
                id="amount"
                type="number"
                placeholder="0.00"
                value={betAmount}
                onChange={(e) => setBetAmount(e.target.value)}
                className="font-mono pr-20"
                data-testid="input-bet-amount"
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 flex gap-2">
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 px-2 text-xs"
                  onClick={() => setBetAmount("10")}
                  data-testid="button-preset-10"
                >
                  10
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 px-2 text-xs"
                  onClick={() => setBetAmount("50")}
                  data-testid="button-preset-50"
                >
                  50
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 px-2 text-xs"
                  onClick={() => setBetAmount("100")}
                  data-testid="button-preset-100"
                >
                  100
                </Button>
              </div>
            </div>
          </div>

          <Card className="p-4 bg-accent/30">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Selected Odds</span>
                <span className="font-mono font-semibold" data-testid="text-summary-odds">{selectedOdds}%</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Your Bet</span>
                <span className="font-mono font-semibold" data-testid="text-summary-bet">{amount.toFixed(2)} QIE</span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="font-medium flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-primary" />
                  Potential Return
                </span>
                <span className="font-mono font-bold text-lg text-primary" data-testid="text-potential-return">
                  {potentialReturn.toFixed(2)} QIE
                </span>
              </div>
            </div>
          </Card>

          <div className="flex gap-3">
            <Button variant="outline" onClick={onClose} className="flex-1" data-testid="button-cancel-bet">
              Cancel
            </Button>
            <Button onClick={handleConfirm} className="flex-1 rounded-full" disabled={!betAmount || amount <= 0} data-testid="button-confirm-bet">
              <Wallet className="h-4 w-4 mr-2" />
              Confirm Bet
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
