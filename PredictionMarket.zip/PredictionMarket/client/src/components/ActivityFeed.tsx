import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { TrendingUp, TrendingDown, Clock } from "lucide-react";

interface Activity {
  id: string;
  user: string;
  action: "bet" | "created" | "resolved";
  market: string;
  amount?: number;
  outcome?: string;
  timestamp: string;
}

// todo: remove mock functionality
const mockActivities: Activity[] = [
  {
    id: "1",
    user: "0x742d...5f3a",
    action: "bet",
    market: "Bitcoin $100k by 2025?",
    amount: 250,
    outcome: "Yes",
    timestamp: "2 min ago"
  },
  {
    id: "2",
    user: "0x8a3b...2c1d",
    action: "created",
    market: "AI will surpass human intelligence by 2030?",
    timestamp: "15 min ago"
  },
  {
    id: "3",
    user: "0x5f2a...9b4c",
    action: "bet",
    market: "Ethereum ETF approval in 2025?",
    amount: 500,
    outcome: "No",
    timestamp: "32 min ago"
  },
  {
    id: "4",
    user: "0x1c8d...3e7f",
    action: "resolved",
    market: "Tesla stock above $300 in Q1?",
    timestamp: "1 hour ago"
  },
  {
    id: "5",
    user: "0x9d4e...6a2b",
    action: "bet",
    market: "Bitcoin $100k by 2025?",
    amount: 100,
    outcome: "Yes",
    timestamp: "2 hours ago"
  },
];

export default function ActivityFeed() {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <Clock className="h-5 w-5 text-primary" />
          Live Activity
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px] pr-4">
          <div className="space-y-4">
            {mockActivities.map((activity) => (
              <div key={activity.id} className="flex items-start gap-3 pb-4 border-b last:border-0 last:pb-0">
                <div className="rounded-full h-8 w-8 bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                  {activity.action === "bet" && activity.outcome === "Yes" && (
                    <TrendingUp className="h-4 w-4 text-green-500" />
                  )}
                  {activity.action === "bet" && activity.outcome === "No" && (
                    <TrendingDown className="h-4 w-4 text-red-500" />
                  )}
                  {activity.action === "created" && (
                    <span className="text-primary text-xs font-bold">+</span>
                  )}
                  {activity.action === "resolved" && (
                    <span className="text-primary text-xs font-bold">✓</span>
                  )}
                </div>

                <div className="flex-1 min-w-0 space-y-1">
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-sm">
                      <span className="font-mono font-medium text-muted-foreground">{activity.user}</span>
                      {" "}
                      <span className="text-muted-foreground">
                        {activity.action === "bet" && "placed a bet on"}
                        {activity.action === "created" && "created"}
                        {activity.action === "resolved" && "resolved"}
                      </span>
                    </p>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">{activity.timestamp}</span>
                  </div>

                  <p className="text-sm font-medium line-clamp-1">{activity.market}</p>

                  {activity.action === "bet" && (
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge variant={activity.outcome === "Yes" ? "default" : "secondary"} className="text-xs">
                        {activity.outcome}
                      </Badge>
                      <span className="text-xs font-mono font-semibold text-primary">
                        {activity.amount} QIE
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
