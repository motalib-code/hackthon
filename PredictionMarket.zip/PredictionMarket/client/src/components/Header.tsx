import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Wallet, Menu, X, Moon, Sun } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDark, setIsDark] = useState(false);
  const [isConnected, setIsConnected] = useState(false); // todo: remove mock functionality
  const [address, setAddress] = useState(""); // todo: remove mock functionality

  const handleConnectWallet = () => {
    // todo: remove mock functionality
    setIsConnected(true);
    setAddress("0x742d...5f3a");
    console.log("Connect wallet triggered");
  };

  const toggleTheme = () => {
    setIsDark(!isDark);
    document.documentElement.classList.toggle("dark");
    console.log("Theme toggled");
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-8">
            <Link href="/" data-testid="link-home">
              <div className="flex items-center gap-2 hover-elevate cursor-pointer px-2 py-1 rounded-md">
                <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-primary to-chart-2 flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-lg">P</span>
                </div>
                <span className="text-xl font-bold bg-gradient-to-r from-primary to-chart-2 bg-clip-text text-transparent">
                  PredictAI
                </span>
              </div>
            </Link>

            <nav className="hidden md:flex items-center gap-6">
              <Link href="/markets" data-testid="link-markets">
                <span className="text-sm font-medium text-foreground hover:text-primary cursor-pointer transition-colors">
                  Markets
                </span>
              </Link>
              <Link href="/create" data-testid="link-create">
                <span className="text-sm font-medium text-foreground hover:text-primary cursor-pointer transition-colors">
                  Create
                </span>
              </Link>
              <Link href="/portfolio" data-testid="link-portfolio">
                <span className="text-sm font-medium text-foreground hover:text-primary cursor-pointer transition-colors">
                  Portfolio
                </span>
              </Link>
              <Link href="/analytics" data-testid="link-analytics">
                <span className="text-sm font-medium text-foreground hover:text-primary cursor-pointer transition-colors">
                  Analytics
                </span>
              </Link>
            </nav>
          </div>

          <div className="flex items-center gap-3">
            <Button
              size="icon"
              variant="ghost"
              onClick={toggleTheme}
              data-testid="button-theme-toggle"
              className="rounded-full"
            >
              {isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>

            {isConnected ? (
              <Badge variant="secondary" className="font-mono text-xs px-3 py-2" data-testid="badge-wallet-address">
                <div className="h-2 w-2 rounded-full bg-green-500 mr-2"></div>
                {address}
              </Badge>
            ) : (
              <Button
                onClick={handleConnectWallet}
                data-testid="button-connect-wallet"
                className="rounded-full"
              >
                <Wallet className="h-4 w-4 mr-2" />
                Connect Wallet
              </Button>
            )}

            <Button
              size="icon"
              variant="ghost"
              className="md:hidden rounded-full"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              data-testid="button-menu-toggle"
            >
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {isMenuOpen && (
          <nav className="md:hidden py-4 border-t space-y-3">
            <Link href="/markets">
              <div className="text-sm font-medium text-foreground hover:text-primary py-2" data-testid="link-mobile-markets">
                Markets
              </div>
            </Link>
            <Link href="/create">
              <div className="text-sm font-medium text-foreground hover:text-primary py-2" data-testid="link-mobile-create">
                Create
              </div>
            </Link>
            <Link href="/portfolio">
              <div className="text-sm font-medium text-foreground hover:text-primary py-2" data-testid="link-mobile-portfolio">
                Portfolio
              </div>
            </Link>
            <Link href="/analytics">
              <div className="text-sm font-medium text-foreground hover:text-primary py-2" data-testid="link-mobile-analytics">
                Analytics
              </div>
            </Link>
          </nav>
        )}
      </div>
    </header>
  );
}
