import PortfolioTable from '../PortfolioTable';

export default function PortfolioTableExample() {
  return (
    <div className="p-6 bg-background">
      <PortfolioTable />
    </div>
  );
}
