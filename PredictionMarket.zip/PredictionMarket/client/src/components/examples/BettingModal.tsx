import { useState } from 'react';
import BettingModal from '../BettingModal';
import { Button } from '@/components/ui/button';

export default function BettingModalExample() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="p-6 bg-background">
      <Button onClick={() => setIsOpen(true)}>Open Betting Modal</Button>
      <BettingModal
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        marketQuestion="Will Bitcoin reach $100,000 by end of 2025?"
        outcomes={[
          { label: "Yes", odds: 68 },
          { label: "No", odds: 32 }
        ]}
      />
    </div>
  );
}
