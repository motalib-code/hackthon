import StatsCard from '../StatsCard';
import { Wallet } from 'lucide-react';

export default function StatsCardExample() {
  return (
    <div className="p-6 bg-background">
      <StatsCard
        title="Total Value"
        value="2,450 QIE"
        subtitle="$12,250 USD"
        icon={Wallet}
        trend="+12.5% this week"
        trendUp={true}
      />
    </div>
  );
}
