import AnalyticsDashboard from '../AnalyticsDashboard';

export default function AnalyticsDashboardExample() {
  return (
    <div className="p-6 bg-background">
      <AnalyticsDashboard />
    </div>
  );
}
