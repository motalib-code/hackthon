import ActivityFeed from '../ActivityFeed';

export default function ActivityFeedExample() {
  return (
    <div className="p-6 bg-background">
      <ActivityFeed />
    </div>
  );
}
