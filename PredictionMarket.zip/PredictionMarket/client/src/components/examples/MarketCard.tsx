import MarketCard from '../MarketCard';

export default function MarketCardExample() {
  return (
    <div className="p-6 bg-background">
      <MarketCard
        id="1"
        question="Will Bitcoin reach $100,000 by end of 2025?"
        category="Crypto"
        outcomes={[
          { label: "Yes", odds: 68 },
          { label: "No", odds: 32 }
        ]}
        aiProbability={68}
        aiInsight="Technical analysis shows strong bullish momentum with institutional adoption increasing"
        totalPool={15420}
        participants={342}
        endDate="Dec 31, 2025"
      />
    </div>
  );
}
