import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, TrendingUp, Users, Sparkles } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface MarketCardProps {
  id: string;
  question: string;
  category: string;
  outcomes: { label: string; odds: number }[];
  aiProbability: number;
  aiInsight: string;
  totalPool: number;
  participants: number;
  endDate: string;
}

export default function MarketCard({
  question,
  category,
  outcomes,
  aiProbability,
  aiInsight,
  totalPool,
  participants,
  endDate,
}: MarketCardProps) {
  return (
    <Card className="overflow-hidden hover-elevate cursor-pointer transition-all" data-testid={`card-market-${question}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3 mb-2">
          <h3 className="font-semibold text-lg leading-tight flex-1" data-testid="text-market-question">
            {question}
          </h3>
          <Badge variant="secondary" className="text-xs uppercase tracking-wide" data-testid="badge-category">
            {category}
          </Badge>
        </div>
        
        <div className="bg-accent/30 rounded-lg p-3 border border-accent-border">
          <div className="flex items-start gap-2">
            <div className="rounded-full bg-primary/10 p-1.5 mt-0.5">
              <Sparkles className="h-3.5 w-3.5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-baseline gap-2 mb-1">
                <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">AI Prediction</span>
                <span className="text-2xl font-bold font-mono text-primary" data-testid="text-ai-probability">
                  {aiProbability}%
                </span>
              </div>
              <p className="text-xs text-muted-foreground line-clamp-2" data-testid="text-ai-insight">
                {aiInsight}
              </p>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="pb-3 space-y-2">
        {outcomes.map((outcome, idx) => (
          <div key={idx} className="space-y-1.5">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium" data-testid={`text-outcome-${idx}`}>{outcome.label}</span>
              <span className="font-mono font-semibold text-primary" data-testid={`text-odds-${idx}`}>
                {outcome.odds}%
              </span>
            </div>
            <Progress value={outcome.odds} className="h-1.5" />
          </div>
        ))}
      </CardContent>

      <CardFooter className="pt-3 border-t flex-wrap gap-3">
        <div className="flex items-center gap-5 text-xs text-muted-foreground flex-1">
          <div className="flex items-center gap-1.5" data-testid="text-pool">
            <TrendingUp className="h-3.5 w-3.5" />
            <span className="font-mono font-medium">{totalPool} QIE</span>
          </div>
          <div className="flex items-center gap-1.5" data-testid="text-participants">
            <Users className="h-3.5 w-3.5" />
            <span>{participants}</span>
          </div>
          <div className="flex items-center gap-1.5" data-testid="text-end-date">
            <Calendar className="h-3.5 w-3.5" />
            <span>{endDate}</span>
          </div>
        </div>
        <Button size="sm" className="rounded-full" data-testid="button-place-bet">
          Place Bet
        </Button>
      </CardFooter>
    </Card>
  );
}
