import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: string;
  subtitle?: string;
  icon: LucideIcon;
  trend?: string;
  trendUp?: boolean;
}

export default function StatsCard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  trendUp,
}: StatsCardProps) {
  return (
    <Card className="hover-elevate transition-all">
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="space-y-2 flex-1">
            <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide" data-testid="text-stats-title">
              {title}
            </p>
            <div>
              <p className="text-3xl font-bold font-mono" data-testid="text-stats-value">
                {value}
              </p>
              {subtitle && (
                <p className="text-sm text-muted-foreground mt-1" data-testid="text-stats-subtitle">
                  {subtitle}
                </p>
              )}
            </div>
            {trend && (
              <p className={`text-xs font-medium ${trendUp ? 'text-green-500' : 'text-red-500'}`} data-testid="text-stats-trend">
                {trend}
              </p>
            )}
          </div>
          <div className="rounded-lg bg-primary/10 p-3">
            <Icon className="h-6 w-6 text-primary" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
