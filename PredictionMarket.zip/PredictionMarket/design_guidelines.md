# Design Guidelines: AI-Powered Decentralized Prediction Market

## Design Approach

**Reference-Based Approach**: Drawing inspiration from leading Web3 and prediction market platforms including Polymarket, Uniswap, and modern DeFi dashboards, combined with the polished aesthetics of Stripe and the clean data visualization of Linear.

**Core Design Principles**:
- Future-forward Web3 aesthetic that builds trust through transparency and professionalism
- Data-first visualization emphasizing real-time market dynamics and AI insights
- Sophisticated yet accessible interface that abstracts blockchain complexity
- Glassmorphism and depth effects creating premium, modern feeling

---

## Typography System

**Primary Font**: Inter or DM Sans via Google Fonts
- Hero Headlines: 48-64px, font-weight 700, tight line-height (1.1)
- Section Headers: 32-40px, font-weight 700
- Card Titles: 20-24px, font-weight 600
- Body Text: 16px, font-weight 400, line-height 1.6
- Data/Stats: 14-16px, font-weight 500, tabular numbers
- Labels/Captions: 12-14px, font-weight 500, uppercase tracking-wide

**Secondary Font**: JetBrains Mono for numerical data, odds, token amounts, wallet addresses

---

## Layout System

**Spacing Primitives**: Use Tailwind units of 2, 4, 8, 12, 16, 24 (p-2, p-4, p-8, etc.)
- Component internal padding: 4-8 units
- Section padding: 12-24 units  
- Card spacing: 4-6 gap
- Generous whitespace between major sections: 16-24 units

**Grid Systems**:
- Dashboard/Markets: 3-column grid (lg:grid-cols-3) collapsing to single column mobile
- Market cards: 2-column tablet (md:grid-cols-2), single mobile
- Portfolio stats: 4-column desktop (lg:grid-cols-4), 2-column tablet

**Container Strategy**:
- Full-width wrapper with max-w-7xl centered content
- Edge-to-edge sections with internal max-width containers
- Cards within 16-20px horizontal padding

---

## Component Library

### Navigation
**Structure**: Fixed top navigation with glassmorphism backdrop blur
- Logo left, wallet connection button right
- Navigation links centered (Markets, Create, Portfolio, Analytics)
- Wallet button shows connected address (truncated: 0x1234...5678) or "Connect Wallet"
- Mobile: Hamburger menu with slide-out drawer

### Hero Section (Homepage)
**Layout**: Full-width split hero (60/40 split)
- Left: Bold headline "AI-Powered Prediction Markets on QIE Blockchain", subheadline, dual CTAs ("Explore Markets" primary, "Create Market" secondary)
- Right: Large abstract illustration or animated gradient mesh representing blockchain/AI fusion
- Background: Subtle grid pattern with gradient overlay
- Height: 80vh desktop, natural height mobile

### Market Cards
**Structure**: Elevated cards with glassmorphism effect
- Header: Market question (bold, 20px) with category badge
- AI Insight Section: Compact panel with robot icon, probability percentage (large, 36px), brief AI analysis snippet
- Outcomes Grid: 2-column outcome options showing current odds as large percentages
- Footer: Metadata bar showing total pool, end date, participant count with icons
- Hover: Lift effect with increased shadow

### Market Creation Form
**Layout**: Multi-step wizard (3 steps: Event Details → Outcomes & Odds → Review)
- Progress indicator dots at top
- Single column form with generous 8-unit spacing between fields
- Rich text input for event description
- Dynamic outcome builder allowing 2-5 options
- AI Assistant sidebar suggesting improvements (collapsed on mobile)

### Betting Interface
**Modal/Drawer**: Full-screen mobile, centered modal desktop
- Market question at top
- Outcome selection as large radio cards
- Bet amount input with max/preset buttons (10 QIE, 50 QIE, 100 QIE)
- Potential return calculator showing live calculation
- Transaction summary card
- Confirm button full-width at bottom

### Portfolio Dashboard
**Layout**: Multi-section dashboard with sidebar + main area split
- Sidebar: User stats cards (Total Value, Win Rate, Markets Active) stacked vertically
- Main: Tab navigation (Active Bets, History, Rewards)
- Active Bets: Table/card hybrid showing market, position, current value, potential return
- Visual indicators: Green/red for winning/losing positions
- Charts: Line graph for portfolio value over time

### Analytics Section
**Grid Layout**: 2x2 stats grid at top, followed by charts
- Key metrics: Total Markets, Active Participants, AI Accuracy Rate, Total Volume
- Charts: Bar chart for market categories, line chart for platform activity, donut for outcome distribution

### Market Resolution Display
**Winner Announcement**: Full-width banner for resolved markets
- Bold outcome label, checkmark icon
- Distribution breakdown showing winner payouts
- Oracle data sources listed with verification badges

---

## Interactive Elements

**Buttons**:
- Primary: Full rounded (rounded-full), medium padding (px-8 py-3), bold font-weight
- Secondary: Outlined variant with same dimensions
- Icon buttons: Square/circle with single icon, 40x40px minimum hit area
- Wallet button: Rounded pill with wallet icon + text/address

**Form Inputs**:
- Rounded borders (rounded-lg), focused ring effect
- Floating labels or persistent labels above input
- Icon prefixes for special inputs (currency symbol for amounts)
- Validation states with inline messages

**Cards**:
- Rounded corners (rounded-xl to rounded-2xl)
- Subtle border + shadow for depth
- Glassmorphism: Semi-transparent backgrounds with backdrop-blur-md on overlays
- Hover states: Transform scale-105 with shadow increase

**Data Visualization**:
- Use Recharts or Chart.js for live market data
- Gradient fills for area charts
- Tooltip overlays on hover
- Responsive scaling maintaining aspect ratios

**Loading States**:
- Skeleton screens matching card layouts
- Pulsing animation for loading data
- Transaction pending: Spinning icon with status text

---

## Spacing & Rhythm

**Vertical Rhythm**:
- Section padding: py-16 mobile, py-24 desktop
- Card internal spacing: p-6 to p-8
- Stacked elements: space-y-6 to space-y-8
- Form fields: space-y-4

**Horizontal Spacing**:
- Grid gaps: gap-6 to gap-8
- Inline elements: space-x-4
- Container padding: px-4 mobile, px-8 desktop

---

## Images

**Hero Image**: Large abstract 3D illustration representing blockchain network + AI brain fusion (right side of split hero, ~800x600px). Style: Modern, gradient-rich, floating geometric elements.

**Market Category Icons**: Custom SVG icons for different prediction categories (Sports, Politics, Crypto, Entertainment) displayed on market cards and filters.

**Empty States**: Illustration for "No active markets" or "No bets placed" - friendly, minimal line art style.

**AI Badge Graphics**: Small animated icon/badge indicating AI-powered predictions, displayed prominently on market cards.

**Trust Badges**: Oracle verification logos, QIE blockchain logo, security audit badges in footer.

---

## Web3-Specific Patterns

**Wallet Connection States**:
- Disconnected: Clear CTA to connect
- Connecting: Loading spinner with "Connecting..." text
- Connected: Shows truncated address with identicon/avatar
- Wrong Network: Warning banner prompting network switch to QIE (Chain ID 1990)

**Transaction Flows**:
- Step 1: Review transaction details
- Step 2: "Confirm in wallet" message with wallet logo
- Step 3: "Transaction pending" with block explorer link
- Step 4: Success confirmation with confetti or success animation

**Token Display**:
- Always show token symbol (QIE) after amounts
- Use monospace font for precision
- Truncate long decimals (max 4 decimal places displayed)

**Real-time Updates**:
- Live updating odds with smooth number transitions
- Activity feed showing recent bets as they happen
- WebSocket connection indicator (small green dot) in header

---

## Accessibility Standards

- Keyboard navigation for all interactive elements
- Focus indicators with visible rings
- ARIA labels for icon-only buttons
- Minimum contrast ratios for text
- Screen reader support for wallet states and transaction flows
- Responsive text sizing maintaining readability across devices